if (!navigator.cookieEnabled)
    window.location = "forbidden.php";
