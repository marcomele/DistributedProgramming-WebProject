<?php
	session_start();
	include("library.php");
	logout(false);
?>
