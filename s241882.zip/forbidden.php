<?php
	header("HTTP/1.1 403 Forbidden");
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/4.1.1.css" />
</head>
	<body>
		<div class="non-bidder" style="margin-top: 0.2em">
			403 Forbidden: This site needs cookies to work. Your browser's settings do not allow cookies. You can not continue the navigation unless you enable cookies for this site.
		</div>
		<noscript><div class="msg" style="margin-top: 0.2em">
			Warning: this site will not work properly unless JavaScript is enabled. Please enable javascript in your browser settings.
		</div></noscript>
	</body>
</html>
